# 
# Hangman
#

import random
import string

WORDLIST_FILENAME = "words.txt"

def load_words():
    """
    Returns a list of valid words. Words are strings of lowercase letters.
    
    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print "Loading word list from file..."
    words_file = open(WORDLIST_FILENAME, 'r')
    words = []
    for line in words_file:
        words.append(line.strip().lower())
    print "  ", len(words), "words loaded."
    return words

def choose_word(words):
    """
    Returns a word from words at random.

    words (list): list of words (strings)
    """
    return random.choice(words)

# actually load the dictionary of words and point to it with 
# the wordlist variable so that it can be accessed from anywhere
# in the program
words = load_words()
